/* Modificado automáticamente: renombrado HTML/CSS y limpieza básica de Java */
package polimorfismo;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class NotificacionTest {
    @Test
    public void testEmail() {
        NotificacionEmail e = new NotificacionEmail("user@mail.com", "Hola", "Bienvenida");
        assertEquals("Bienvenida", e.getAsunto());
        assertEquals("user@mail.com", e.getDestinatario());
    }

    @Test
    public void testPush() {
        NotificacionPush p = new NotificacionPush("Celular", "Alerta", 1);
        assertEquals(1, p.getPrioridad());
    }

    @Test
    public void testSMS() {
        NotificacionSMS s = new NotificacionSMS("123456", "Info", 999);
        assertEquals(999, s.getnumeroRemitente());
    }
}