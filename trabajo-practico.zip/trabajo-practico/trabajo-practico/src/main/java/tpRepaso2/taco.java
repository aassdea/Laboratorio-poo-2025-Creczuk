/* Modificado automáticamente: renombrado HTML/CSS y limpieza básica de Java */
package tpRepaso2;

public class taco extends calzado {
    public taco(int id, int talle, double precioBase) {
        super(id, talle, precioBase);
    }

    @Override
    public double getPrecioVenta() {
        return precioBase * 1.3;
    }
}