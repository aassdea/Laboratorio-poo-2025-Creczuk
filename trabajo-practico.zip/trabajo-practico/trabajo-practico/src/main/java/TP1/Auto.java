/* Modificado automáticamente: renombrado HTML/CSS y limpieza básica de Java */
package TP1;

public class Auto extends Vehiculo {
    private String tipoCombustible;

    public String gettipoCombustible() { return tipoCombustible; }
    public void settipoCombustible(String tipoCombustible) { this.tipoCombustible = tipoCombustible; }
    
    @Override
    public void mover() { }
}