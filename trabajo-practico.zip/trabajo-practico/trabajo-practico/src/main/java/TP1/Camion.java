/* Modificado automáticamente: renombrado HTML/CSS y limpieza básica de Java */
package TP1;

public class Camion extends Vehiculo {
    private String cargaMaxima;

    public String getcargaMaxima() { return cargaMaxima; }
    public void setcargaMaxima(String cargaMaxima) { this.cargaMaxima = cargaMaxima; }
    
    @Override
    public void mover() { }
}