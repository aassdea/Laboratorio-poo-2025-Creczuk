/* Modificado automáticamente: renombrado HTML/CSS y limpieza básica de Java */
package TP1;

public class Moto extends Vehiculo {
    private String cilindrada;

    public String getCilindrada() { return cilindrada; }
    public void setCilindrada(String cilindrada) { this.cilindrada = cilindrada; }
    
    @Override
    public void mover() { }
}