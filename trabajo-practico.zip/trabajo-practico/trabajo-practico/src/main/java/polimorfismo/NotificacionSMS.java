/* Modificado automáticamente: renombrado HTML/CSS y limpieza básica de Java */
package polimorfismo;

public class NotificacionSMS extends Notificacion {
    private int numeroRemitente;

    public NotificacionSMS(String destinatario, String contenido, int numeroRemitente) {
        super(destinatario, contenido);
        this.setnumeroRemitente(numeroRemitente);
    }

    public int getnumeroRemitente() { return numeroRemitente; }
    public void setnumeroRemitente(int numeroRemitente) { this.numeroRemitente = numeroRemitente; }

    @Override
    public void enviar() {
        System.out.println("Enviando SMS a " + getDestinatario() + " desde " + numeroRemitente + " y contenido " + getContenido());
    }
}