package com.example.demo.service;

import org.json.JSONObject;
import org.springframework.stereotype.Service;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

@Service
public class ClimaService {

    private final String API_KEY = "tu_api_key";

    public String obtenerClima(String ciudad) {
        try {
            String urlStr = "https://api.openweathermap.org/data/2.5/weather?q="
                    + ciudad + "&appid=" + API_KEY + "&units=metric&lang=es";

            URL url = new URL(urlStr);

            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            Scanner sc = new Scanner(conn.getInputStream());
            StringBuilder json = new StringBuilder();

            while (sc.hasNext()) {
                json.append(sc.nextLine());
            }
            sc.close();

            JSONObject data = new JSONObject(json.toString());

            String nombre = data.getString("name");
            double temp = data.getJSONObject("main").getDouble("temp");
            String desc = data.getJSONArray("weather").getJSONObject(0).getString("description");

            return "Ciudad: " + nombre + "\nTemperatura: " + temp + "°C\nClima: " + desc;

        } catch (Exception e) {
            return "No se pudo obtener el clima de " + ciudad;
        }
    }
}