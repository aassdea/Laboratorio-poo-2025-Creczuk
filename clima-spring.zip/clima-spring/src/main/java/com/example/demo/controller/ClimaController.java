package com.example.demo.controller;

import com.example.demo.service.ClimaService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/clima")
public class ClimaController {

    private final ClimaService servicio;

    public ClimaController(ClimaService servicio) {
        this.servicio = servicio;
    }

    @GetMapping("/{ciudad}")
    public String mostrarClima(@PathVariable String ciudad) {
        return servicio.obtenerClima(ciudad);
    }
}