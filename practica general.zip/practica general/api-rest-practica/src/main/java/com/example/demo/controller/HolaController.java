package com.example.demo.controller;

import java.util.Map;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HolaController {

    @GetMapping("/hola")
    public Map<String, String> hola() {
        return Map.of("mensaje", "holiii omg mi primera api con tomcat increible");
    }
}
