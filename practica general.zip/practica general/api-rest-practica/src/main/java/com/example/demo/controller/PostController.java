package com.example.demo.controller;

import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.PokemonResult;
import com.example.demo.service.PokemonService;

@RestController
public class PostController {

    private final PokemonService pokemonService;

    public PostController(PokemonService pokemonService) {
        this.pokemonService = pokemonService;
    }

    @GetMapping("/posts")
    public Map<String, String> mostrarPokemon() {

        // Imprime en consola (punto 3)
        pokemonService.mostrarPokemonesEnConsola();

        // Toma el primer Pokemon (punto 4)
        PokemonResult primerPokemon = pokemonService
                .traerPokemones()
                .getResults()
                .get(0);

        // Devuelve "titulo" y "texto" como pide la consigna
        return Map.of(
                "titulo", primerPokemon.getName(),
                "texto", primerPokemon.getUrl()
        );
    }
}
