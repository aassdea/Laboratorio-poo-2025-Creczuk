package com.Farmacia.Controller;

import com.Farmacia.Model.Medicamento;
import com.Farmacia.Service.MedicamentoService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/medicamentos")
public class MedicamentoController {

    private final MedicamentoService service;

    public MedicamentoController(MedicamentoService service) {
        this.service = service;
    }

    @PostMapping
    public Medicamento crear(@RequestBody Medicamento m) {
        return service.agregar(m);
    }

    @GetMapping
    public List<Medicamento> listar() {
        return service.listar();
    }

    @GetMapping("/{id}")
    public Medicamento obtener(@PathVariable Long id) {
        return service.buscarPorId(id);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        service.eliminar(id);
    }

    @GetMapping("/critico")
    public List<Medicamento> stockCritico() {
        return service.stockCritico();
    }
}