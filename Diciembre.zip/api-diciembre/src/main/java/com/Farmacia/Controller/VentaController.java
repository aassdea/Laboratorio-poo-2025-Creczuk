package com.Farmacia.Controller;

import com.Farmacia.Model.Venta;
import com.Farmacia.Service.MedicamentoService;
import com.Farmacia.Service.VentaService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/ventas")
public class VentaController {

    private final VentaService ventaService;
    private final MedicamentoService medicamentoService;

    public VentaController(VentaService ventaService, MedicamentoService medicamentoService) {
        this.ventaService = ventaService;
        this.medicamentoService = medicamentoService;
    }

    @PostMapping
    public Venta vender(
            @RequestParam Long idMedicamento,
            @RequestParam int cantidad,
            @RequestParam String tipoPago,
            @RequestParam(required = false, defaultValue = "0") int cuotas
    ) {
        return ventaService.registrarVenta(
                medicamentoService.buscarPorId(idMedicamento),
                cantidad,
                tipoPago,
                cuotas
        );
    }

    @GetMapping("/total")
    public double totalVendido() {
        return ventaService.totalVendido();
    }
}