package com.Farmacia.Model;

public abstract class Empleado {

    protected String nombre;
    protected int dni;

    public Empleado(String nombre, int dni) {
        this.nombre = nombre;
        this.dni = dni;
    }

    public abstract double calcularSalario();
}