package com.Farmacia.Model;

import java.util.Date;

public class Venta {

    private Date fecha;
    private int cantidad;
    private Medicamento medicamento;
    private Pago pago;
    private double total;

    public Venta(Medicamento medicamento, int cantidad, Pago pago) {
        this.fecha = new Date();
        this.medicamento = medicamento;
        this.cantidad = cantidad;
        this.pago = pago;
        this.total = calcularTotal();
    }

    public double calcularTotal() {
        return pago.procesarPago();
    }

    public double getTotal() {
        return total;
    }

    public Medicamento getMedicamento() {
        return medicamento;
    }

    public int getCantidad() {
        return cantidad;
    }

    public Date getFecha() {
        return fecha;
    }

    public Pago getPago() {
        return pago;
    }
}