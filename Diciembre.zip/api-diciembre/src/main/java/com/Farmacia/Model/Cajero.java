package com.Farmacia.Model;

public class Cajero extends Empleado {

    private int horasTrabajadas;
    private double valorHora;

    public Cajero(String nombre, int dni, int horasTrabajadas, double valorHora) {
        super(nombre, dni);
        this.horasTrabajadas = horasTrabajadas;
        this.valorHora = valorHora;
    }

    @Override
    public double calcularSalario() {
        return horasTrabajadas * valorHora;
    }
}