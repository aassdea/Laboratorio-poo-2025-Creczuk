package com.Farmacia.Model;

public class PagoTarjeta extends Pago {

    private int cuotas;
    private double interes;

    public PagoTarjeta(double monto, int cuotas, double interes) {
        super(monto);
        this.cuotas = cuotas;
        this.interes = interes;
    }

    @Override
    public double procesarPago() {
        return monto + (monto * interes);
    }
}