package com.Farmacia.Model;

public class Farmaceutico extends Empleado {

    private double sueldoFijo;

    public Farmaceutico(String nombre, int dni, double sueldoFijo) {
        super(nombre, dni);
        this.sueldoFijo = sueldoFijo;
    }

    @Override
    public double calcularSalario() {
        return sueldoFijo;
    }
}
