package com.Farmacia.Model;

public class PagoEfectivo extends Pago {

    private double descuento;

    public PagoEfectivo(double monto, double descuento) {
        super(monto);
        this.descuento = descuento;
    }

    @Override
    public double procesarPago() {
        return monto - (monto * descuento);
    }
}