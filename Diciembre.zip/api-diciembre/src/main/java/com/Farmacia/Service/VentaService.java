package com.Farmacia.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.Farmacia.Model.Medicamento;
import com.Farmacia.Model.Pago;
import com.Farmacia.Model.PagoEfectivo;
import com.Farmacia.Model.PagoTarjeta;
import com.Farmacia.Model.Venta;

@Service
public class VentaService {

    private List<Venta> ventas = new ArrayList<>();

    public Venta registrarVenta(
            Medicamento medicamento,
            int cantidad,
            String tipoPago,
            int cuotas
    ) {

        if (cantidad <= 0) {
            throw new RuntimeException("Cantidad inválida");
        }

        if (cantidad > medicamento.getStock()) {
            throw new RuntimeException("Stock insuficiente");
        }

        double montoBase = medicamento.getPrecio() * cantidad;
        Pago pago;

        switch (tipoPago.toLowerCase()) {
            case "efectivo":
                pago = new PagoEfectivo(montoBase, 0.10); // 10% desc
                break;

            case "tarjeta":
                pago = new PagoTarjeta(montoBase, cuotas, 0.15); // 15% interés
                break;

            default:
                throw new RuntimeException("Tipo de pago inválido");
        }

        medicamento.setStock(medicamento.getStock() - cantidad);

        Venta venta = new Venta(medicamento, cantidad, pago);
        ventas.add(venta);

        return venta;
    }

    public double totalVendido() {
        double total = 0;
        for (Venta v : ventas) {
            total += v.getTotal();
        }
        return total;
    }
}