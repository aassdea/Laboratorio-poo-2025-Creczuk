package com.Farmacia.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.Farmacia.Model.Medicamento;

@Service
public class MedicamentoService {

    private List<Medicamento> medicamentos = new ArrayList<>();
    private Long contadorId = 1L;

    public Medicamento agregar(Medicamento m) {

        if (m.getPrecio() <= 0) {
            throw new RuntimeException("El precio debe ser mayor a cero");
        }

        if (m.getNombre() == null || m.getNombre().isBlank()) {
            throw new RuntimeException("El nombre es obligatorio");
        }

        Medicamento nuevo = new Medicamento(
                contadorId++,
                m.getNombre(),
                m.getCategoria(),
                m.getPrecio(),
                m.getStock()
        );

        medicamentos.add(nuevo);
        return nuevo;
    }

    public List<Medicamento> listar() {
        return medicamentos;
    }

    public Medicamento buscarPorId(Long id) {
        for (Medicamento m : medicamentos) {
            if (m.getId().equals(id)) {
                return m;
            }
        }
        throw new RuntimeException("Medicamento no encontrado");
    }

    public void eliminar(Long id) {
        Medicamento m = buscarPorId(id);
        medicamentos.remove(m);
    }

    public List<Medicamento> stockCritico() {
        List<Medicamento> criticos = new ArrayList<>();

        for (Medicamento m : medicamentos) {
            if (m.getStock() < 10) {
                criticos.add(m);
            }
        }
        return criticos;
    }
}