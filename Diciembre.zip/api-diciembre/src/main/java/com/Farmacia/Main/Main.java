package com.Farmacia.Main;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.Farmacia.Model.Medicamento;
import com.Farmacia.Model.Venta;
import com.Farmacia.Service.MedicamentoService;
import com.Farmacia.Service.VentaService;

@SpringBootApplication
public class Main {

    public static void main(String[] args) {
        SpringApplication.run(Main.class, args);
    }

    // EJECUCIÓN POR CONSOLA (OBLIGATORIO SEGÚN CONSIGNA)
    @Bean
    CommandLineRunner init(MedicamentoService medicamentoService,
                           VentaService ventaService) {

        return args -> {

            System.out.println("=== SISTEMA DE FARMACIA ===");

            // Crear medicamentos
            Medicamento m1 = new Medicamento(null, "Paracetamol", "Analgesico", 100, 20);
            Medicamento m2 = new Medicamento(null, "Ibuprofeno", "Antiinflamatorio", 150, 15);

            medicamentoService.agregar(m1);
            medicamentoService.agregar(m2);

            System.out.println("Medicamentos cargados");

            // Registrar ventas
            Venta v1 = ventaService.registrarVenta(m1, 2, "efectivo", 0);
            Venta v2 = ventaService.registrarVenta(m2, 3, "tarjeta", 3);

            System.out.println("Venta 1 total: $" + v1.getTotal());
            System.out.println("Venta 2 total: $" + v2.getTotal());

            // Total vendido
            double total = ventaService.totalVendido();
            System.out.println("TOTAL VENDIDO: $" + total);
        };
    }
}