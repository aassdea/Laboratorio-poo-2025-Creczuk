package com.Farmacia.Model;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class VentaTest {

    @Test
    void calcularTotalVenta() {
        Medicamento m = new Medicamento(1L, "Amoxicilina", "Antibiotico", 500, 10);
        Pago pago = new PagoEfectivo(1000, 0.10);

        Venta venta = new Venta(m, 2, pago);

        assertEquals(900, venta.getTotal());
    }
}