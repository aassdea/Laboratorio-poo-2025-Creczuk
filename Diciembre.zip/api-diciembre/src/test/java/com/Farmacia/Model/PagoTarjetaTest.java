package com.Farmacia.Model;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import com.Farmacia.Model.Pago;
import com.Farmacia.Model.PagoTarjeta;

public class PagoTarjetaTest {

    @Test
    void procesarPagoConInteres() {
        Pago pago = new PagoTarjeta(1000, 3, 0.15);

        double total = pago.procesarPago();

        assertEquals(1150, total);
    }
}