package com.Farmacia.Model;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class PagoEfectivoTest {

    @Test
    void procesarPagoConDescuento() {
        Pago pago = new PagoEfectivo(1000, 0.10);

        double total = pago.procesarPago();

        assertEquals(900, total);
    }
}