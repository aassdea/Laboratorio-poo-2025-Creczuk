package com.Farmacia.Model;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class MedicamentoTest {

    @Test
    void crearMedicamentoCorrectamente() {
        Medicamento m = new Medicamento(1L, "Paracetamol", "Analgesico", 100.0, 20);

        assertEquals("Paracetamol", m.getNombre());
        assertEquals(100.0, m.getPrecio());
        assertEquals(20, m.getStock());
    }

    @Test
    void modificarStock() {
        Medicamento m = new Medicamento(1L, "Ibuprofeno", "Analgesico", 200.0, 10);
        m.setStock(5);

        assertEquals(5, m.getStock());
    }
}
