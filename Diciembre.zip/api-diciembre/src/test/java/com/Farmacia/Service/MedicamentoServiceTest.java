package com.Farmacia.Service;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import com.Farmacia.Model.Medicamento;

public class MedicamentoServiceTest {

    @Test
    void agregarMedicamentoValido() {
        MedicamentoService service = new MedicamentoService();

        Medicamento m = new Medicamento(null, "Aspirina", "Analgesico", 150, 20);
        Medicamento agregado = service.agregar(m);

        assertNotNull(agregado.getId());
    }

    @Test
    void noPermitirPrecioInvalido() {
        MedicamentoService service = new MedicamentoService();

        Medicamento m = new Medicamento(null, "Error", "Test", 0, 10);

        assertThrows(RuntimeException.class, () -> service.agregar(m));
    }
}