package com.Farmacia.Service;


import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import com.Farmacia.Model.Medicamento;
import com.Farmacia.Model.Venta;

public class VentaServiceTest {

    @Test
    void registrarVentaCorrectamente() {
        VentaService service = new VentaService();
        Medicamento m = new Medicamento(1L, "Paracetamol", "Analgesico", 100, 10);

        Venta venta = service.registrarVenta(m, 2, "efectivo", 0);

        assertEquals(8, m.getStock());
        assertTrue(venta.getTotal() > 0);
    }

    @Test
    void noPermitirVentaSinStock() {
        VentaService service = new VentaService();
        Medicamento m = new Medicamento(1L, "Ibuprofeno", "Analgesico", 100, 1);

        assertThrows(RuntimeException.class, () ->
                service.registrarVenta(m, 5, "efectivo", 0)
        );
    }
}